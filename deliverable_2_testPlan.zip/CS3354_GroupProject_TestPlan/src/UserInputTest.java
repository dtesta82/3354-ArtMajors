import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class UserInputTest {
	@BeforeClass
	public static void beforeClass() {
		System.out.println("Before Class");
	}
	
	@Before
	public void before() {
		System.out.println("Before Test Case");
	}
	
	@Test
	public void isGreaterTest() {
		System.out.println("Test");
		UserInput userInput = new UserInput();
		assertEquals("Here is the test for multiplication", 2000, userInput.subtraction(1000,1000));
	}
	
	@After
	public void after() {
		System.out.println("After Test Case");
	}
	
	@AfterClass
	public static void afterClass() {
		System.out.println("After Class");
	}
}
