import java.util.Scanner;
public class UserInput {

	public static int subtraction(int income, int expense){
		int sub = income - expense;
		return sub;
	}
	
	
}
